// Get the button and output element
const btn = document.getElementById('btn');
const output = document.getElementById('output');

// Add event listener for 'click' event
btn.addEventListener('click', function() {
    output.textContent = 'Button clicked!';
});
